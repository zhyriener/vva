import os
from flask import Flask, render_template

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "valley_view_academy_secret")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/academics')
def academics():
    return render_template('academics.html')

@app.route('/admissions')
def admissions():
    return render_template('admissions.html')

@app.route('/campus-life')
def campus_life():
    return render_template('campus-life.html')

@app.route('/news-events')
def news_events():
    return render_template('news-events.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/students')
def students():
    return render_template('students.html')

@app.route('/faculty')
def faculty():
    return render_template('faculty.html')

@app.route('/alumni')
def alumni():
    return render_template('alumni.html')

@app.route('/research')
def research():
    return render_template('research.html')

@app.route('/about-vva')
def about_vva():
    return render_template('about-vva.html')

# Additional routes for pages from attached assets
@app.route('/leadership')
def leadership():
    return render_template('about.html', section='leadership')

@app.route('/accreditation')
def accreditation():
    return render_template('about.html', section='accreditation')

@app.route('/mission-vision')
def mission_vision():
    return render_template('about.html', section='mission-vision')

@app.route('/school-history')
def school_history():
    return render_template('about.html', section='school-history')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
