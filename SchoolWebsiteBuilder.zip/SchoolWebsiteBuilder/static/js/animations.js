document.addEventListener('DOMContentLoaded', function() {
    // Scroll animations for elements
    const animateOnScroll = function() {
        const elementsToAnimate = document.querySelectorAll('.animate-on-scroll');
        
        elementsToAnimate.forEach(element => {
            const elementPosition = element.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;
            
            if (elementPosition < windowHeight - 100) {
                const animation = element.dataset.animation || 'fade-in';
                element.classList.add(animation);
            }
        });
    };
    
    // Initialize elements with animation class
    const initAnimations = function() {
        const sections = document.querySelectorAll('section');
        
        sections.forEach(section => {
            section.querySelectorAll('h2, h3, p, .btn, .card, .grid-item').forEach(element => {
                if (!element.classList.contains('animate-on-scroll')) {
                    element.classList.add('animate-on-scroll');
                    element.classList.add('hidden-element');
                    
                    // Assign animation type based on element
                    if (element.tagName === 'H2' || element.tagName === 'H3') {
                        element.dataset.animation = 'fade-in';
                    } else if (element.classList.contains('btn')) {
                        element.dataset.animation = 'fade-in-delay';
                    } else {
                        element.dataset.animation = 'slide-up';
                    }
                }
            });
        });
    };
    
    // Hero section animation
    const animateHero = function() {
        const heroContent = document.querySelector('.hero-content');
        if (heroContent) {
            setTimeout(() => {
                heroContent.style.opacity = '1';
                heroContent.style.transform = 'translateY(0)';
            }, 300);
        }
    };
    
    // Counter animation for stats
    const animateCounters = function() {
        const counters = document.querySelectorAll('.stat-number');
        const speed = 200; // The lower the slower
        
        counters.forEach(counter => {
            const animate = () => {
                const value = +counter.dataset.count;
                const data = +counter.innerText;
                
                const time = value / speed;
                if (data < value) {
                    counter.innerText = Math.ceil(data + time);
                    setTimeout(animate, 1);
                } else {
                    counter.innerText = value;
                }
            };
            
            animate();
        });
    };
    
    // Run animations on scroll
    window.addEventListener('scroll', function() {
        animateOnScroll();
    });
    
    // Initialize
    initAnimations();
    animateHero();
    animateOnScroll();
    
    // Animate counters when they're in viewport
    const statSection = document.querySelector('.stats-section');
    if (statSection) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCounters();
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });
        
        observer.observe(statSection);
    }
    
    // Image slider for campus life section
    const setupSlider = function() {
        const sliders = document.querySelectorAll('.image-slider');
        
        sliders.forEach(slider => {
            const slides = slider.querySelectorAll('.slider-slide');
            if (slides.length === 0) return;
            
            let currentSlide = 0;
            const slideInterval = 5000; // 5 seconds
            
            // Show first slide
            slides[0].classList.add('active');
            
            // Next slide function
            const nextSlide = () => {
                slides[currentSlide].classList.remove('active');
                currentSlide = (currentSlide + 1) % slides.length;
                slides[currentSlide].classList.add('active');
            };
            
            // Auto slide
            let slideTimer = setInterval(nextSlide, slideInterval);
            
            // Pause on hover
            slider.addEventListener('mouseenter', () => {
                clearInterval(slideTimer);
            });
            
            slider.addEventListener('mouseleave', () => {
                slideTimer = setInterval(nextSlide, slideInterval);
            });
            
            // Navigation dots
            if (slides.length > 1) {
                const dotsContainer = document.createElement('div');
                dotsContainer.className = 'slider-dots';
                
                for (let i = 0; i < slides.length; i++) {
                    const dot = document.createElement('span');
                    dot.className = 'slider-dot';
                    if (i === 0) dot.classList.add('active');
                    
                    dot.addEventListener('click', () => {
                        slides[currentSlide].classList.remove('active');
                        document.querySelectorAll('.slider-dot').forEach(d => d.classList.remove('active'));
                        
                        currentSlide = i;
                        slides[currentSlide].classList.add('active');
                        dot.classList.add('active');
                    });
                    
                    dotsContainer.appendChild(dot);
                }
                
                slider.appendChild(dotsContainer);
            }
        });
    };
    
    setupSlider();
});
